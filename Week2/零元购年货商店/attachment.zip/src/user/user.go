package user

type User struct {
	Name    string
	Created int64
	Uid     string
}
